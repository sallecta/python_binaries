# please run fix_portable_path.sh
portable_path=/initial/portable/path
