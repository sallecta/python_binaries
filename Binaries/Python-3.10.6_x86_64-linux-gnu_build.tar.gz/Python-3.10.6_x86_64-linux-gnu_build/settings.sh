#settings_python_version="3.9.16"
settings_python_version="3.10.6"
settings_python_version_short="3.10"
settings_path_portable_initial="/initial/portable/path"
