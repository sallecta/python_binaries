portable_path=/run_fix_portable.sh
